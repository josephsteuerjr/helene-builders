import './fixtures/ru-localization.mjs';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { stripTypeScriptTypes } from 'node:module';
const kit = new URL('../../ui-kit/', import.meta.url);
const mod = source => 'data:text/javascript;base64,'+Buffer.from(stripTypeScriptTypes(source)).toString('base64');
const text = mod(readFileSync(new URL('text.ts',kit),'utf8'));
const {runOriginText} = await import(text);
const dom = mod(readFileSync(new URL('dom.ts',kit),'utf8').replace('"./text"',JSON.stringify(text)));
const lens = mod(readFileSync(new URL('tool-lens.ts',kit),'utf8').replace('"./text"',JSON.stringify(text)));
const steps = await import(mod(readFileSync(new URL('steps.ts',kit),'utf8').replace('"./text"',JSON.stringify(text)).replace('"./dom"',JSON.stringify(dom)).replace('"./tool-lens"',JSON.stringify(lens))));
const source=stripTypeScriptTypes(readFileSync(new URL('window/panel.ts',kit),'utf8'));
const fn=source.slice(source.indexOf('function stepRows('),source.indexOf('\nfunction openLink('));
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
const render=new Function('clean','icon','esc','clip','fmtK','toolIcon','ACTIONS','toolTraceHTML','toolSummary','frameStripHTML','terminalLabel','textBox','subject','runOriginText',fn+';return stepRows;')(
  s=>s,s=>'',esc,steps.clip,String,()=>'',steps.ACTIONS,steps.toolTraceHTML,steps.toolSummary,()=>'',steps.terminalLabel,steps.textBox,steps.subject,runOriginText);
const detail={id:'fixture',manifest:{status:'running'},iterations:[{call_id:'m',tools:[{
  call_id:'real',tool:'shell',args:{cmd:'echo <request>'},execution:{handler:'agent.tool_shell',status:'entered'},
  operations:[{kind:'process',argv:['bash','-lc','echo <actual>'],status:'returned',exit_code:0}],result:{head:'done'},
}]}]};
const row=render(detail).find(row=>row.key==='tool:real');
assert(!row.cls.includes(' open'),'new actions occupy a compact row');
assert.match(row.html,/aria-expanded="false"/);
assert.match(row.html,/class="st-detail" hidden/);
assert.match(row.html,/exit 0/);
assert.match(row.html,/echo &lt;actual&gt;/,'exact observed invocation remains available');
assert.match(row.html,/Процесс · exit 0/);
assert.match(row.html,/\$ bash -lc /,'the observed process is shown as its shell line');
assert.match(row.html,/agent\.tool_shell\(cmd=/,'the Python hand is shown as handler(**args)');
assert.doesNotMatch(row.html,/<actual>/,'observed command remains inert');
console.log('Production panel: compact defaults, visible harness execution and inert full trace PASS');
const uncertain=render({...detail,manifest:{status:'in_doubt'}}).find(row=>row.key==='uncertainty');
assert.match(uncertain.html,/неизвестен/);assert.match(uncertain.html,/повтора нет/);
assert.equal(render(detail).some(row=>row.key==='uncertainty'),false);
const rowSource=source.slice(source.indexOf('function rowOf('),source.indexOf('\nfunction metaOf('));
const rowOf=new Function('clean','noteWords','clip','fmtTime','turnAt','EV_KIND',rowSource+';return rowOf;')(
  String,String,steps.clip,String,()=>'',{});
assert.equal(rowOf({run_id:'old-media',out:'authored text'},{status:'in_doubt'},'').status,'attention');
assert.equal(rowOf({run_id:'complete',out:'authored text'},{status:'done'},'').status,'done');

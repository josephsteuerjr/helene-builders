import { t as uiText } from "../../lang/lang";
import '../../ui-kit/fonts.css';
import '../../ui-kit/tokens.css';
import '../../ui-kit/window/styles/paper-tokens.css';
import './tray.css';
import { shell } from '../../ui-kit/window/api';
import { apply, load } from '../../ui-kit/window/look';
import { engineCommand, exitNote, trayStatus, type TrayState } from '../../ui-kit/tray-state';

const root = document.querySelector<HTMLElement>('#tray')!;
let state: TrayState | null = null;
let pending = false;
let timer: number | undefined;
let error = '';
let generation = 0;
let contextError = false;
let snapshot = '';
const element = <K extends keyof HTMLElementTagNameMap>(tag: K, cls: string, text = '') => {
  const node = document.createElement(tag); node.className = cls; node.textContent = text; return node;
};
const hide = () => shell('tray_hide').catch(() => {});
const focusControl = (node: HTMLElement | null) => {
  node?.focus({ preventScroll: true });
  (node?.dataset.action === 'exit' ? node.parentElement : node)?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
};

async function action(run: () => Promise<unknown>, close = true) {
  if (pending) return;
  const focusKey = document.activeElement instanceof HTMLElement ? document.activeElement.dataset.action : undefined;
  pending = true; error = ''; contextError = false; paint();
  try { await run(); if (close) await hide(); }
  catch (e) {
    error = e instanceof Error ? e.message : String(e); paint();
    if (!document.hasFocus()) void shell('notify', { title: 'Hélène', body: error }).catch(() => {});
  } finally {
    pending = false; if (!close && !error) await refresh(); paint();
    if (focusKey && document.hasFocus()) focusControl(root.querySelector<HTMLElement>(`[data-action="${CSS.escape(focusKey)}"]`));
  }
}

function button(label: string, run: () => Promise<unknown>, close = true) {
  const node = element('button', 'tray-action', label); node.type = 'button'; node.disabled = pending;
  node.addEventListener('click', () => void action(run, close)); return node;
}

function paint() {
  const focused = document.activeElement instanceof HTMLElement ? document.activeElement.dataset.action : undefined;
  const scrollTop = root.scrollTop;
  const agentsScroll = root.querySelector('.tray-agents')?.scrollTop || 0;
  root.replaceChildren();
  root.style.maxHeight = Math.max(160, Math.min(580, state?.max_height ?? window.innerHeight) - 48) + 'px';
  root.append(element('div', 'tray-brand', 'Hélène'));
  if (!state) {
    root.append(element('p', 'tray-status', error ? uiText("ui.app.src.tray.dc5d75e557") : uiText("ui.app.src.tray.da0cbed896")));
  } else {
    const current = state.agents.find(a => a.id === state!.current);
    const name = element('h1', 'tray-name', current?.name || uiText("ui.app.src.tray.d5fd08be28")); name.title = name.textContent || '';
    root.append(name);
    const status = trayStatus(state.owner);
    const row = element('div', 'tray-status');
    row.append(element('span', 'tray-dot ' + status.tone), element('span', '', pending ? uiText("ui.app.src.tray.05a2107ccd") : status.text));
    root.append(row);
    if (state.agents.length > 1) {
      const agents = element('div', 'tray-agents'); agents.setAttribute('aria-label', uiText("ui.app.src.tray.fc616048bf"));
      for (const a of state.agents) {
        const pick = button(a.name, () => shell('switch_agent', { id: a.id }));
        pick.dataset.action = 'agent:' + a.id;
        pick.classList.add('tray-agent'); pick.classList.toggle('current', a.id === state.current);
        pick.setAttribute('aria-pressed', String(a.id === state.current)); pick.title = a.conflict || a.name;
        pick.disabled ||= !!a.conflict; agents.append(pick);
      }
      root.append(agents);
    }
  }
  const open = button(uiText("ui.app.src.tray.eded461928"), () => shell('tray_open_main')); open.dataset.action = 'open'; root.append(open);
  if (state) {
    const cmd = engineCommand(state.owner);
    const stopped = !!state.owner.stopped || state.owner.enabled === false || state.owner.runner_alive === false;
    const control = button(stopped ? uiText("ui.app.src.tray.de5b2d1b50") : uiText("ui.app.src.tray.0d4f3f205a"), () => shell(cmd!.cmd, cmd!.args), false);
    control.dataset.action = 'engine'; control.disabled ||= !cmd;
    if (!cmd) control.title = uiText("ui.app.src.tray.bbddaa47ea");
    root.append(control);
    if (state.owner.supported && !state.owner.stopped && stopped) {
      const panic = button(uiText("ui.app.src.tray.278ceeea7e"), () => shell('owner_control', { action: 'panic' }), false);
      panic.dataset.action = 'panic'; root.append(panic);
    }
  }
  if (error) { const msg = element('p', 'tray-error', error); msg.setAttribute('role', 'alert'); root.append(msg); }
  const footer = element('div', 'tray-footer');
  const quit = button(uiText("ui.app.src.tray.776fccddab"), () => shell('tray_exit')); quit.dataset.action = 'exit'; footer.append(quit);
  if (state) footer.append(element('p', 'tray-note', exitNote(state)));
  root.append(footer);
  root.scrollTop = scrollTop;
  const list = root.querySelector('.tray-agents'); if (list) list.scrollTop = agentsScroll;
  if (focused) focusControl(root.querySelector<HTMLElement>(`[data-action="${CSS.escape(focused)}"]`));
  if (document.hasFocus()) void fit();
}

async function fit() {
  await document.fonts.ready;
  const height = Math.ceil(root.getBoundingClientRect().height + 48);
  await shell('tray_fit', { height }).catch(() => {});
}

async function refresh() {
  if (pending) return;
  const stamp = ++generation;
  try {
    const fresh = await shell<TrayState>('tray_context');
    if (stamp !== generation) return;
    const next = JSON.stringify(fresh);
    if (next === snapshot && !contextError) return;
    state = fresh; snapshot = next;
    if (contextError) { contextError = false; error = ''; }
    paint();
  } catch (e) {
    if (stamp !== generation) return;
    contextError = true; error = e instanceof Error ? e.message : String(e); paint();
  }
}

function opened() {
  apply(load()); void refresh();
  clearInterval(timer); timer = window.setInterval(() => void refresh(), 1500);
  requestAnimationFrame(() => root.querySelector<HTMLButtonElement>('[data-action="open"]')?.focus());
}
window.addEventListener('focus', opened);
window.addEventListener('blur', () => { clearInterval(timer); ++generation; void hide(); });
window.addEventListener('storage', () => apply(load()));
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { e.preventDefault(); void hide(); return; }
  const buttons = [...root.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')];
  if (!buttons.length) return;
  const index = buttons.indexOf(document.activeElement as HTMLButtonElement);
  let next: number | undefined;
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') next = (index + (e.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
  else if (e.key === 'Home') next = 0;
  else if (e.key === 'End') next = buttons.length - 1;
  else if (e.key === 'Tab') next = (index + (e.shiftKey ? -1 : 1) + buttons.length) % buttons.length;
  if (next !== undefined) { e.preventDefault(); focusControl(buttons[next]); }
});
apply(load()); paint();
if (document.hasFocus()) opened();
